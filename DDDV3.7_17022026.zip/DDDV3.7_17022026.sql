-- ---------------------------------------------------
-- DDDV3.7
-- ---------------------------------------------------
alter table cms_card.np_card_batch_request add (remarks_clob clob);
update cms_card.np_card_batch_request set remarks_clob = to_clob(remarks);
alter table cms_card.np_card_batch_request drop column remarks;
alter table cms_card.np_card_batch_request rename column remarks_clob to remarks;